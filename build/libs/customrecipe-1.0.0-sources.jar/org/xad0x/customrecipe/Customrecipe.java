package org.xad0x.customrecipe;

import net.fabricmc.api.ModInitializer;

public class Customrecipe implements ModInitializer {

    @Override
    public void onInitialize() {
    }
}
