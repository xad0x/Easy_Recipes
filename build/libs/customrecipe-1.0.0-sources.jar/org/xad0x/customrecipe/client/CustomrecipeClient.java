package org.xad0x.customrecipe.client;

import net.fabricmc.api.ClientModInitializer;

public class CustomrecipeClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
    }
}
